
#True , False stmt execution    if -else

#[True] , False stmt execution  if -elif - else

# True , False {Ture - False {True - False}.........} nested if - else 

# match - case - case _ 

# for my_name in class_attendence
#    else:


#while 


#exception

    #try:
    #    if -elif - else
    
    #except:
    #    captue any error / specific error
    #    IndexError: list index out of range

list=[0,1,2,3,4,5,5,6]

index = 0  #starting
while index < 7: #ending at 6  1,2,3,4,5 , 6 break the loop 
  print(index) 
  index = index + 1        #iterate mnaully 
  print("------>")
  print(list[index])

 
