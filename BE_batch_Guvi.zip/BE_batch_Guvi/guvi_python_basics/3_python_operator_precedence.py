a = 12 + (6 * 4)

print(a)


#()
#**
#*/
#+-

#[on_true] if [expression] else [on_false] 
#expression : conditional_expression | lambda_expr
a, b = 10, 20
min = a if a < b else b

print(min)