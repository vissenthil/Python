
print("python basic data types")
a = 5
print("Type of a: ", type(a))

b = 5.0
print("Type of b: \n", type(b))

d = "hello"
print("\nTypde od d:", type(d))

c = 2 + 4j 
print("\nType of c: ", type(c))


#boolean -> TRUE or FALSE
str1='hi'
print('i' in str1) 

print("data type conversion")
#int -> string 

x=str(a)
print(x)

#int -> float 
y=float(a)
print(x)

#int -> array 

#string -> list 



