
print("python inbuilt math functions")
#Addition
a=10+2
print("result of addition:",a)
#Subtraction
b=200-10
print("result of subraction:",b)
#Multiplication
c=10*2
print("result of multiplication:",c)
#Division
d=45/9
print("result of subraction:",d)
#Modulo
e=12%2
print("result of subraction:",e)
#Power
f=12**2 
#or
#f=pow(12,2)
print("result of subraction:",f)