

#snake_case
#start with lower case or underscore
#Letters, numbers and underscores
#Case Sensitive
#Dont overwrite keywords
 

#Case Sensitive

input_var = "hello"
print(input_Var)  #case sensitive 