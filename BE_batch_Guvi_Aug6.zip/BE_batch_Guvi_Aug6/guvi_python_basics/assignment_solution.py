from collections import Counter

str1 = "save"
str2 = "vase"

c1 = Counter(str1)
c2 = Counter(str2)
print(c1)
print(c2)
print(c1 == c2)