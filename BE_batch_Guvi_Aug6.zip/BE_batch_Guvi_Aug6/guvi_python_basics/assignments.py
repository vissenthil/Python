
#find if below two strings annagrams or not 

str1 = "save"
str2 = "vase"


#find if any given string is palidrome or not 
inp_string="madam"
inp_string="maths"


